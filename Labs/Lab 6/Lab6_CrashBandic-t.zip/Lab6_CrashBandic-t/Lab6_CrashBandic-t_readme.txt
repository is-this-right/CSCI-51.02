Before compiling the code, do the following:
* replace the first argument in line 48 with the path of your xclock in your machine
* if you can't find xclock, enter into your terminal: which xclock
* compile the code

Description:
This is a simple timer application. 
In the terminal is the parent process that updates every 10 seconds after the first print.
The child process opens xclock, a visual representation of the clock.